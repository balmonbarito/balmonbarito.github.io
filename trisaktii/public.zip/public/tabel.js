function tabel(){
  // Try edit message
  var yoman =[];
  var label =[];
  var bep = [];
  var tabel="";
  var cek="";
  var nomer=[];
  //get data from google sheets
  $.getJSON("https://spreadsheets.google.com/feeds/cells/1GHGSAhFZgN1AbTUP9RbBtvkXaNqtVeKWvGnhHlBFR7Q/2/public/basic?alt=json" ,function (data){
    var gan = data.feed.entry;
    for (var i = 0; i<gan.length; i++) {
          yoman.push(gan[i].content.$t); 
      } 
    for(var j = 24; j<yoman.length; j++){
      if(yoman[j]!==""){
          label.push(yoman[j]);
      }
    }
    for(var i = 0; i <(label.length/24); i++){
      var lop = i*24;
      tabel += '<tr><th scope="row">'+ (i+1) +'</th>';
      for (var j=lop; j<(lop+4); j++){
        tabel += '<td>'+ label[j] + '</td>';

      }
      tabel += '<td><button type="button" class="btn btn-info btn-sm" onclick="mode(this.id);"'+ 'id= "tombol'+ (i+1) +'"' +'>LH05</button></td></tr>';
    }
    
    var hasil = document.getElementById('outputtabel');
    hasil.innerHTML = tabel;
  });
}
function tabelapp(){
  // Try edit message
  var yoman =[];
  var label =[];
  var bep = [];
  var tabel="";
  var cek="";
  var nomer=[];
  //get data from google sheets
  $.getJSON("https://spreadsheets.google.com/feeds/cells/1GHGSAhFZgN1AbTUP9RbBtvkXaNqtVeKWvGnhHlBFR7Q/3/public/basic?alt=json" ,function (data){
    var gan = data.feed.entry;
    for (var i = 0; i<gan.length; i++) {
          yoman.push(gan[i].content.$t); 
      } 
    for(var j = 24; j<yoman.length; j++){
      if(yoman[j]!==""){
          label.push(yoman[j]);
      }
    }
    for(var i = 0; i <(label.length/24); i++){
      var lop = i*24;
      tabel += '<tr><th scope="row">'+ (i+1) +'</th>';
      for (var j=lop; j<(lop+4); j++){
        tabel += '<td>'+ label[j] + '</td>';

      }
      tabel += '<td><button type="button" class="btn btn-info btn-sm" onclick="modeapp(this.id);"'+ 'id= "tombol'+ (i+1) +'"' +'>LH05</button></td><td><button type="button" class="btn btn-danger btn-sm"'+ 'id= "tombol'+ (i+1) +'"' +'>Need Approval</button></td></tr>';
    }
    
    var hasil = document.getElementById('outputtabelapp');
    hasil.innerHTML = tabel;
  });
}
// Get the modal
var modal = document.getElementById("myModal");

// When the user clicks the button, open the modal 
function mode(clicked) {
  var yoman =[];
  var label =[];


  //get data from google sheets
  $.getJSON("https://spreadsheets.google.com/feeds/cells/1GHGSAhFZgN1AbTUP9RbBtvkXaNqtVeKWvGnhHlBFR7Q/2/public/basic?alt=json" ,function (data){
    var gan = data.feed.entry;
    for (var i = 0; i<gan.length; i++) {
          yoman.push(gan[i].content.$t); 
      } 
    for(var j = 24; j<yoman.length; j++){
      if(yoman[j]!==""){
          label.push(yoman[j]);
      }
    }
    var elText1="";
    var elText2="";
    for(var k = 1; k<(label.length/24)+1; k++){
      if(clicked == "tombol"+k){
        var jsb = label[(k-1)*24+10];
        document.getElementById('jsb').innerHTML = jsb;
        var jsb = label[(k-1)*24+11];
        document.getElementById('jsmo').innerHTML = jsb;
        var waktu = label[(k-1)*24+3] + " ("+label[(k-1)*24+4]+") WITA";
        document.getElementById('waktu').innerHTML = waktu;

        var mesin = label[(k-1)*24];
        if(mesin == "Mesin 2"){
          document.getElementById("no").innerHTML="II (Dua)";
          document.getElementById("tipe").innerHTML="Sulzer 12 ZV 40/48";
          document.getElementById("seri").innerHTML="740023";
          document.getElementById("dmn").innerHTML="6.400 KW";

        }
        if(mesin == "Mesin 3"){
          document.getElementById("no").innerHTML="III (Tiga)";
          document.getElementById("tipe").innerHTML="Pielstick 12 PC 2.4V";
          document.getElementById("seri").innerHTML="3140";
          document.getElementById("dmn").innerHTML="5.400 KW";

        }
        if(mesin == "Mesin 5"){
          document.getElementById("no").innerHTML="V (Lima)";
          document.getElementById("tipe").innerHTML="SWD 16 TM 410R";
          document.getElementById("seri").innerHTML="3666";
          document.getElementById("dmn").innerHTML="8.800 KW";

        }
        if(mesin == "Mesin 6"){
          document.getElementById("no").innerHTML="VI (Enam)";
          document.getElementById("tipe").innerHTML="SWD 16 TM 410R";
          document.getElementById("seri").innerHTML="3667";
          document.getElementById("dmn").innerHTML="8.800 KW";

        }
        if(mesin == "Mesin 9"){
          document.getElementById("no").innerHTML="IX (Sembilan)";
          document.getElementById("tipe").innerHTML="SWD 9 TM 620C";
          document.getElementById("seri").innerHTML="62100";
          document.getElementById("dmn").innerHTML="12.400 KW";

        }
        if(mesin == "Mesin 10"){
          document.getElementById("no").innerHTML="X (Sepuluh)";
          document.getElementById("tipe").innerHTML="SWD 9 TM 620C";
          document.getElementById("seri").innerHTML="62000";
          document.getElementById("dmn").innerHTML="12.400 KW";

        }

        var spd = label[(k-1)*24+1];
        document.getElementById('spd').innerHTML = spd;
        var part = label[(k-1)*24+2];
        document.getElementById('part').innerHTML = part;
        var gejala = label[(k-1)*24+7];
        document.getElementById('gejala').innerHTML = gejala;
        var urutan = label[(k-1)*24+8];
        document.getElementById('urutan').innerHTML = urutan;
        var analisa = label[(k-1)*24+9];
        document.getElementById('analisa').innerHTML = analisa;
        var mampu = label[(k-1)*24+12];
        document.getElementById('mampu').innerHTML = mampu;
        var puncak = label[(k-1)*24+13];
        document.getElementById('puncak').innerHTML = puncak;
        var tindakan = label[(k-1)*24+14];
        document.getElementById('tindakan').innerHTML = tindakan;
        var pelaksanaan = label[(k-1)*24+15];
        document.getElementById('pelaksanaan').innerHTML = pelaksanaan;
        var pekerjaan = label[(k-1)*24+16];
        document.getElementById('pekerjaan').innerHTML = pekerjaan;
        var material = label[(k-1)*24+17];
        document.getElementById('material').innerHTML = material;
        var biaya = label[(k-1)*24+18];
        document.getElementById('biaya').innerHTML = biaya;
        var lainlain = label[(k-1)*24+19];
        document.getElementById('lainlain').innerHTML = lainlain;
        var manager = label[(k-1)*24+20];
        document.getElementById('manager').innerHTML = manager;
        var namaman = label[(k-1)*24+21];
        document.getElementById('namaman').innerHTML = namaman;
        var spv = label[(k-1)*24+22];
        document.getElementById('spv').innerHTML = spv;
        var namaspv = label[(k-1)*24+23];
        document.getElementById('namaspv').innerHTML = namaspv;

        var qrcode1 = new QRCode(document.getElementById("qrcode1"), {
          width : 90,
          height : 90
        });    
        var qrcode2 = new QRCode(document.getElementById("qrcode2"), {
          width : 90,
          height : 90
        });

        elText1 = namaspv+ ", "+spv+ " ULPLTD/G Trisakti";
        

        elText2 = namaman+ ", "+manager+ " PLTD/G Trisakti ";
        qrcode1.makeCode(elText1);
    qrcode2.makeCode(elText2);
      }
    }
    
  });
  modal.style.display = "block";
  window.onclick = function(event) {
    if (event.target == modal) {
      $("#qrcode1").empty();
      $("#qrcode2").empty();
      modal.style.display = "none";

    }
  }

}
// When the user clicks anywhere outside of the modal, close it
function modeapp(clicked) {
  var yoman =[];
  var label =[];


  //get data from google sheets
  $.getJSON("https://spreadsheets.google.com/feeds/cells/1GHGSAhFZgN1AbTUP9RbBtvkXaNqtVeKWvGnhHlBFR7Q/3/public/basic?alt=json" ,function (data){
    var gan = data.feed.entry;
    for (var i = 0; i<gan.length; i++) {
          yoman.push(gan[i].content.$t); 
      } 
    for(var j = 24; j<yoman.length; j++){
      if(yoman[j]!==""){
          label.push(yoman[j]);
      }
    }
    var elText1="";
    var elText2="";
    for(var k = 1; k<(label.length/24)+1; k++){
      if(clicked == "tombol"+k){
        var jsb = label[(k-1)*24+10];
        document.getElementById('jsb').innerHTML = jsb;
        var jsb = label[(k-1)*24+11];
        document.getElementById('jsmo').innerHTML = jsb;
        var waktu = label[(k-1)*24+3] + " ("+label[(k-1)*24+4]+") WITA";
        document.getElementById('waktu').innerHTML = waktu;

        var mesin = label[(k-1)*24];
        if(mesin == "Mesin 2"){
          document.getElementById("no").innerHTML="II (Dua)";
          document.getElementById("tipe").innerHTML="Sulzer 12 ZV 40/48";
          document.getElementById("seri").innerHTML="740023";
          document.getElementById("dmn").innerHTML="6.400 KW";

        }
        if(mesin == "Mesin 3"){
          document.getElementById("no").innerHTML="III (Tiga)";
          document.getElementById("tipe").innerHTML="Pielstick 12 PC 2.4V";
          document.getElementById("seri").innerHTML="3140";
          document.getElementById("dmn").innerHTML="5.400 KW";

        }
        if(mesin == "Mesin 5"){
          document.getElementById("no").innerHTML="V (Lima)";
          document.getElementById("tipe").innerHTML="SWD 16 TM 410R";
          document.getElementById("seri").innerHTML="3666";
          document.getElementById("dmn").innerHTML="8.800 KW";

        }
        if(mesin == "Mesin 6"){
          document.getElementById("no").innerHTML="VI (Enam)";
          document.getElementById("tipe").innerHTML="SWD 16 TM 410R";
          document.getElementById("seri").innerHTML="3667";
          document.getElementById("dmn").innerHTML="8.800 KW";

        }
        if(mesin == "Mesin 9"){
          document.getElementById("no").innerHTML="IX (Sembilan)";
          document.getElementById("tipe").innerHTML="SWD 9 TM 620C";
          document.getElementById("seri").innerHTML="62100";
          document.getElementById("dmn").innerHTML="12.400 KW";

        }
        if(mesin == "Mesin 10"){
          document.getElementById("no").innerHTML="X (Sepuluh)";
          document.getElementById("tipe").innerHTML="SWD 9 TM 620C";
          document.getElementById("seri").innerHTML="62000";
          document.getElementById("dmn").innerHTML="12.400 KW";

        }

        var spd = label[(k-1)*24+1];
        document.getElementById('spd').innerHTML = spd;
        var part = label[(k-1)*24+2];
        document.getElementById('part').innerHTML = part;
        var gejala = label[(k-1)*24+7];
        document.getElementById('gejala').innerHTML = gejala;
        var urutan = label[(k-1)*24+8];
        document.getElementById('urutan').innerHTML = urutan;
        var analisa = label[(k-1)*24+9];
        document.getElementById('analisa').innerHTML = analisa;
        var mampu = label[(k-1)*24+12];
        document.getElementById('mampu').innerHTML = mampu;
        var puncak = label[(k-1)*24+13];
        document.getElementById('puncak').innerHTML = puncak;
        var tindakan = label[(k-1)*24+14];
        document.getElementById('tindakan').innerHTML = tindakan;
        var pelaksanaan = label[(k-1)*24+15];
        document.getElementById('pelaksanaan').innerHTML = pelaksanaan;
        var pekerjaan = label[(k-1)*24+16];
        document.getElementById('pekerjaan').innerHTML = pekerjaan;
        var material = label[(k-1)*24+17];
        document.getElementById('material').innerHTML = material;
        var biaya = label[(k-1)*24+18];
        document.getElementById('biaya').innerHTML = biaya;
        var lainlain = label[(k-1)*24+19];
        document.getElementById('lainlain').innerHTML = lainlain;
        var manager = label[(k-1)*24+20];
        document.getElementById('manager').innerHTML = manager;
        var namaman = label[(k-1)*24+21];
        document.getElementById('namaman').innerHTML = namaman;
        var spv = label[(k-1)*24+22];
        document.getElementById('spv').innerHTML = spv;
        var namaspv = label[(k-1)*24+23];
        document.getElementById('namaspv').innerHTML = namaspv;

        var qrcode1 = new QRCode(document.getElementById("qrcode1"), {
          width : 90,
          height : 90
        });    

        elText1 = namaspv+ ", "+spv+ " ULPLTD/G Trisakti";
        
        qrcode1.makeCode(elText1);
      }
    }
    
  });
  modal.style.display = "block";
  window.onclick = function(event) {
    if (event.target == modal) {
      $("#qrcode1").empty();
      modal.style.display = "none";

    }
  }

}
