$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

//login function

//logout function
function logout(){
  localStorage.removeItem('cp');
  window.location.replace("/index.html");
}

//date generator
function date(){
  var bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September','Oktober','November', 'Desember'];
  var tanggal = new Date().getDate();
  var _bulan = new Date().getMonth();
  var _tahun = new Date().getYear();
  var tahun = _tahun +1900;
  var bulan = bulan[_bulan];
  var lengkap = 'Banjarmasin, '+ tanggal + ' ' + bulan + ' ' + tahun;
  var tgl = document.getElementById("tgl");
    tgl.innerHTML = lengkap;
  }

